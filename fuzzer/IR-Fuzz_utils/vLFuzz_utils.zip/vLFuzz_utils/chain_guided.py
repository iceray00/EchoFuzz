import argparse
import json
import os
import subprocess

from format_conversion import process_content, save_abi_to_file
from prompt_phases import prompt_to_vfcs_phase1, prompt_vfcs_phase2, prompt_generate_VFCS, prompt_vfcs_abi

def extract_contract_name(file_path):
    """
    从文件路径中提取合同名称
    """
    file_name = os.path.basename(file_path)
    contract_name, _ = os.path.splitext(file_name)
    return contract_name

def chain_guided():
    #
    # Usage:
    # python chain_guided.py -i vfcs_dataset_0_4/${contractName}.sol -m $MODEL_NAME
    #

    default_ctx = 65536

    parser = argparse.ArgumentParser(description="Generate VFCS")

    parser.add_argument("-i", "--input", type=str, help="input single one solidity file",
                        default="./simple_dataset/FindThisHash.sol")
    parser.add_argument("-f", "--input_file", type=str, help="input one file path for Contract source code")
    parser.add_argument("-o", "--output", type=str, default="./vfcs/", help="output path for VFCS")
    parser.add_argument("-m", "--model_name", type=str, default="qwen2_7b", help="model name")
    parser.add_argument("-c", "--ctx", type=int, default=default_ctx, help="The maximum length of the context")
    parser.add_argument("--mode", type=str, default="print", help="'silence' or 'print'. Default is 'print'")

    args = parser.parse_args()

    if args.input:
        try:
            print(f"\n \nReading input file: {args.input}\n \n ")
            with open(args.input, 'r') as file:
                source_code = file.read()

            contract_name = extract_contract_name(args.input)
            print(f"Extracted contract name: {contract_name}")

            result_1 = prompt_to_vfcs_phase1(source_code, model_name=args.model_name, ctx=args.ctx, mode=args.mode)

            result_2 = prompt_vfcs_phase2(result_1, args.input, source_code, model_name=args.model_name, ctx=args.ctx, mode=args.mode)

            result_vfcs = prompt_generate_VFCS(result_1, result_2, args.input, source_code, model_name=args.model_name, ctx=args.ctx, mode=args.mode)

            result_vfcs_abi = prompt_vfcs_abi(result_vfcs, args.input, model_name=args.model_name, ctx=args.ctx, mode=args.mode)
            print(f"\n \nGenerated VFCS ABI:\n \n {result_vfcs_abi}")

            # 调用函数对生成的result_vfcs_abi进行格式处理，转换为正确的JSON格式
            result_vfcs_abi_dict = process_content(result_vfcs_abi)
            if result_vfcs_abi_dict:
                print(f"\n\nConversion successful!:\n\n {result_vfcs_abi_dict}")
            else:
                print("No valid ABI content was processed.")

            # Replace the original key with the new key
            new_result_vfcs_abi_dict = {}
            for index, (key, value) in enumerate(result_vfcs_abi_dict.items(), start=1):
                new_key = f"{contract_name}_VFCS_{index}"
                new_result_vfcs_abi_dict[new_key] = value

            # Make sure the "seed_pool" folder exists
            seed_pool_path = "chain_guided_seed_pool"
            if not os.path.exists(seed_pool_path):
                os.makedirs(seed_pool_path)
                print(f"\n \nCreated folder: \n \n{seed_pool_path}")

            # Create a folder with the current model name
            model_folder_path = os.path.join(seed_pool_path, args.model_name)
            if not os.path.exists(model_folder_path):
                os.makedirs(model_folder_path)
                print(f"\n \nCreated folder: \n \n{model_folder_path}")

            # Save the entire result_vfcs_abi to a file for change_abi.py
            for main_contract_name, abi_info in new_result_vfcs_abi_dict.items():
                json_path = f"{main_contract_name}"
                output_file_path = save_abi_to_file(json_path, abi_info, model_folder_path)

                current_dir = os.path.dirname(os.path.abspath(__file__))
                change_abi_utils_path = os.path.join(current_dir, "utils", "change_abi.py")
                subprocess.run(["python3", change_abi_utils_path, output_file_path, output_file_path, model_folder_path])
                print("\n \nChange ABI successfully!\n \n")

            print("\n \n All steps have been executed!\n \n")

        except FileNotFoundError:
            print(f"File not found: {args.input}")
        except Exception as e:
            print(f"Error reading file: {e}")

if __name__ == "__main__":
    chain_guided()